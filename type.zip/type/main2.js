// external js: draggabilly.pkgd.js

$(function () {
$(".box").draggable({            
    stack: ".box"
    });
});
  
$(function () {
$(".name").draggable({            
    stack: ".name"
    });
});